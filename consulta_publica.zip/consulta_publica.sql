prompt PL/SQL Developer import file
prompt Created on terça-feira, 6 de julho de 2021 by matheustorres
-- Create table
create table RGC_CONSULTA_PUBLICA
(
  id_consulta_publica NUMBER not null,
  id_usuario          NUMBER not null,
  s_arquivo           VARCHAR2(100) not null,
  d_consulta_publica  DATE not null,
  d_upload            DATE not null
)
tablespace SYSTEM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table RGC_CONSULTA_PUBLICA
  is 'Tabela que guarda os dados de Consultas Públicas';
-- Add comments to the columns 
comment on column RGC_CONSULTA_PUBLICA.id_consulta_publica
  is 'Id da consulta pública';
comment on column RGC_CONSULTA_PUBLICA.id_usuario
  is 'Id do usuário que processou a consulta pública';
comment on column RGC_CONSULTA_PUBLICA.s_arquivo
  is 'Arquivo processado';
comment on column RGC_CONSULTA_PUBLICA.d_consulta_publica
  is 'Data da consulta pública';
-- Create/Recreate primary, unique and foreign key constraints 
alter table RGC_CONSULTA_PUBLICA
  add primary key (ID_CONSULTA_PUBLICA)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table RGC_CONSULTA_PUBLICA
  add foreign key (ID_USUARIO)
  references SEC_USUARIO (ID_USUARIO);
-- Create table
create table RGC_CONSULTA_PUBLICA_NCM
(
  id_consulta_publica_ncm NUMBER not null,
  id_consulta_publica     NUMBER not null,
  id_ncm                  NUMBER not null,
  s_descricao_mercadoria  VARCHAR2(4000) not null,
  s_bit_bk                VARCHAR2(3) not null,
  s_sdic                  VARCHAR2(10)
)
tablespace SYSTEM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table RGC_CONSULTA_PUBLICA_NCM
  is 'Tabela que guarda os dados dos NCMs das Consultas Públicas';
-- Add comments to the columns 
comment on column RGC_CONSULTA_PUBLICA_NCM.id_consulta_publica_ncm
  is 'Id do registro de ncm encontrado em uma consulta pública';
comment on column RGC_CONSULTA_PUBLICA_NCM.id_consulta_publica
  is 'Id da consulta pública';
comment on column RGC_CONSULTA_PUBLICA_NCM.id_ncm
  is 'Id do ncm';
comment on column RGC_CONSULTA_PUBLICA_NCM.s_descricao_mercadoria
  is 'Arquivo processado';
comment on column RGC_CONSULTA_PUBLICA_NCM.s_bit_bk
  is 'Data da consulta pública';
-- Create/Recreate primary, unique and foreign key constraints 
alter table RGC_CONSULTA_PUBLICA_NCM
  add primary key (ID_CONSULTA_PUBLICA_NCM)
  using index 
  tablespace SYSTEM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table RGC_CONSULTA_PUBLICA_NCM
  add foreign key (ID_CONSULTA_PUBLICA)
  references RGC_CONSULTA_PUBLICA (ID_CONSULTA_PUBLICA);
alter table RGC_CONSULTA_PUBLICA_NCM
  add foreign key (ID_NCM)
  references RGC_NCM (ID_NCM);
-- Create sequence 
create sequence SEQ_RGCCONSULTAPUBLICA
minvalue 1
maxvalue 99999999
start with 1
increment by 1
nocache;
-- Create sequence 
create sequence SEQ_RGCCONSULTAPUBLICANCM
minvalue 1
maxvalue 99999999
start with 1
increment by 1
nocache;
prompt Loading SEC_ITEM_MENU...
insert into SEC_ITEM_MENU (id_item_menu, id_item_menu_pai, n_nivel, n_ordem, s_pagina, s_nome_base, s_ativo)
values (41, 6, 2, 35, 'consulta_publica.xhtml', 'label_consulta_publica', 'S');
commit;
prompt 1 records loaded
prompt Loading SEC_GRUPO_ITEM_MENU...
insert into SEC_GRUPO_ITEM_MENU (id_grupo_item_menu, id_grupo, id_item_menu)
values (478, 1, 41);
commit;
prompt 1 records loaded
prompt Done.